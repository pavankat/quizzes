
INSERT INTO hobbies (hobby) VALUES ('jogging');

INSERT INTO hobbies (hobby) VALUES ('basketball');

INSERT INTO hobbies (hobby) VALUES ('board games');

INSERT INTO hobbies (hobby) VALUES ('hockey');

INSERT INTO hobbies (hobby) VALUES ('biking');

INSERT INTO hobbies (hobby) VALUES ('swimming');